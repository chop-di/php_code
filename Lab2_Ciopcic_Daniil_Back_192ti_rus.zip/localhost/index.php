<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<style>
   
  </style>
</head>
<body>
	<div class="column">
  <h1>Добавьте студентов</h1>
  <form action="action.php" method="post">  
   
<style>
table, th, td {
  border:1px solid black;
}
</style>
<body>

<h2>Список Студентов</h2>

<table style="width:100%">
  <tr>
    <th>Номер Студента</th>
    <th>Фамилия</th>
    <th>Имя</th>
    <th>Средний балл</th>
  </tr>
  <tr>
    <td><p><label for="number"></label><input type="text" name="number1" required=" " placeholder="Номер  студента"></td>
   <td><p><label for="surname"></label><input type="text" name="surname1" required="" placeholder="Фамилия  студента"></td>
    <td><p><label for="name" ></label><input type="text" name="name1" required=""placeholder="Имя  студента" ></td> 
    <td><p><label for="mark"></label><input type="text" name="mark1" required=" " placeholder="Ср.Балл  студента"><br></td>
  </tr>
<tr>
    <td><p><label for="number"></label><input type="text" name="number2" required=" " placeholder="Номер  студента"></td>
   <td><p><label for="surname"></label><input type="text" name="surname2" required="" placeholder="Фамилия  студента"></td>
    <td><p><label for="name" ></label><input type="text" name="name2" required=""placeholder="Имя  студента" ></td>
    <td><p><label for="mark"></label><input type="text" name="mark2" required=" " placeholder="Ср.Балл  студента"><br></td>
  </tr>
  <tr>
    <td><p><label for="number"></label><input type="text" name="number3" required=" " placeholder="Номер  студента"></td>
   <td><p><label for="surname"></label><input type="text" name="surname3" required="" placeholder="Фамилия  студента"></td>
    <td><p><label for="name" ></label><input type="text" name="name3" required=""placeholder="Имя  студента" ></td>
    <td><p><label for="mark"></label><input type="text" name="mark3" required=" " placeholder="Ср.Балл  студента"><br></td>
  </tr>
  <tr>
    <td><p><label for="number"></label><input type="text" name="number4" required=" " placeholder="Номер  студента"></td>
   <td><p><label for="surname"></label><input type="text" name="surname4" required="" placeholder="Фамилия  студента"></td>
    <td><p><label for="name" ></label><input type="text" name="name4" required=""placeholder="Имя  студента" ></td>
    <td><p><label for="mark"></label><input type="text" name="mark4" required=" " placeholder="Ср.Балл  студента"><br></td>
  </tr>
  <tr>
    <td><p><label for="number"></label><input type="text" name="number5" required=" " placeholder="Номер  студента"></td>
   <td><p><label for="surname"></label><input type="text" name="surname5" required="" placeholder="Фамилия  студента"></td>
    <td><p><label for="name" ></label><input type="text" name="name5" required=""placeholder="Имя  студента" ></td>
    <td><p><label for="mark"></label><input type="text" name="mark5" required=" " placeholder="Ср.Балл  студента"><br></td>
  </tr>
  <tr>
   <td><p><label for="number"></label><input type="text" name="number6" required=" " placeholder="Номер  студента"></td>
   <td><p><label for="surname"></label><input type="text" name="surname6" required="" placeholder="Фамилия  студента"></td>
     <td><p><label for="name" ></label><input type="text" name="name6" required=""placeholder="Имя  студента" ></td>
    <td><p><label for="mark"></label><input type="text" name="mark6" required=" " placeholder="Ср.Балл  студента"><br></td>
  </tr>
  <tr>
  <td><p><label for="number"></label><input type="text" name="number7" required=" " placeholder="Номер  студента"></td>
   <td><p><label for="surname"></label><input type="text" name="surname7" required="" placeholder="Фамилия  студента"></td>
      <td><p><label for="name" ></label><input type="text" name="name7" required=""placeholder="Имя  студента" ></td>
    <td><p><label for="mark"></label><input type="text" name="mark7" required=" " placeholder="Ср.Балл  студента"><br></td>
  </tr>
   
</table>
    <button type="submit" >Добавить Студентов</button>
<button type="submit" onClick="location.href='action.php'">Список всех введёных студентов</button>
     
    
  </form>
	</div>
	 
</body>
</html>
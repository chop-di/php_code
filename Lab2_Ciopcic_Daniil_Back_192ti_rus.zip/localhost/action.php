<!DOCTYPE html>
<html>
<style>
table, th, td {
  border:1px solid black;
}
</style>
<body>

  <h1 align='center'>Список Студентов</h1>

<table style="width:100%">
  
  <tr>

    <th>Номер Студента</th>
      <th>Фамилия</th>
 <th>Имя</th> 
    <th>Средний балл</th>
  </tr>
  <tr>
   <td><?php echo $_POST['number1'];?></td> 
   <td><?php echo $_POST['surname1'];?></td>
    <td><?php echo $_POST['name1'];?></td>
    <td><?php echo $_POST['mark1'];?></td>
  </tr>
  <tr>
   <td><?php echo $_POST['number2'];?></td> 
   <td><?php echo $_POST['surname2'];?></td>
    <td><?php echo $_POST['name2'];?></td>
    <td><?php echo $_POST['mark2'];?></td>
  </tr>
  <tr>
   <td><?php echo $_POST['number3'];?></td> 
   <td><?php echo $_POST['surname3'];?></td>
   <td><?php echo $_POST['name3'];?></td>
    <td><?php echo $_POST['mark3'];?></td>
  </tr>
  <tr>
   <td><?php echo $_POST['number4'];?></td> 
  <td><?php echo $_POST['surname4'];?></td>
     <td><?php echo $_POST['name4'];?></td>
    <td><?php echo $_POST['mark4'];?></td>
  </tr>
  <tr>
   <td><?php echo $_POST['number5'];?></td> 
   <td><?php echo $_POST['surname5'];?></td>
    <td><?php echo $_POST['name5'];?></td>
    <td><?php echo $_POST['mark5'];?></td>
  </tr>
  <tr>
   <td><?php echo $_POST['number6'];?></td> 
   <td><?php echo $_POST['surname6'];?></td>
    <td><?php echo $_POST['name6'];?></td>
    <td><?php echo $_POST['mark6'];?></td>
  </tr>
  <tr>
   <td><?php echo $_POST['number7'];?></td> 
   <td><?php echo $_POST['surname7'];?></td>
    <td><?php echo $_POST['name7'];?></td>
    <td><?php echo $_POST['mark7'];?></td>
  </tr>
</table>
<br>

<?php

$arr;
$i=0;
$j=0;
foreach ($_POST as $key => $value) {
  $arr[$i][$j]=$value;
  $j++;
  
if ($j>3)
{
  $i++;
  $j=0;
} 
}


  $c=0;
$array; 
for($a=0;$a<$i;$a++)
{
   $array[$c]=$arr[$a][0];
$c++;
}

  asort($array);

$temp;
$c=0;
foreach ($array as $key => $value) {
   $temp[$c]=$key;
   $c++;
}
$a = 1;
  $html="<h1 align='center'>По Возрастанию номера Студентов</h1>";
$html.="<table border = '1' cellspacing = '1' align = 'center' style= width:100% border:1px solid black; >";
     $html.="<td></td>
     <td><label>Номер Студента</label>
         <td><label>Фамилия</label></td>
         <td><label>Имя</label></td>
         <td><label>Средний балл</label></td>
     </td>";
          for($s = 0; $s < $i; $s++){
               $html.="<tr align='center'>";
               $html.="<td><b>$a</b></td>";
               for($j = 0; $j < 4; $j++){
                    $html.="<td>";
                    $html.=$arr[$temp[$s]][$j];
                    $html.="</td>";
                    }
               $html.="</tr>";
               ++$a;
          }
     $html.="</table>";
     $html.="<br><br>";
     echo $html;











$c=0;
$array; 
for($a=0;$a<$i;$a++)
{
   $array[$c]=$arr[$a][0];
$c++;
}

  arsort($array);

$temp;
$c=0;
foreach ($array as $key => $value) {
   $temp[$c]=$key;
   $c++;
}
$a = 1;
$html="<h1 align='center'>По Убыванию номера Студентов</h1>";
$html.="<table border = '2' cellspacing = '0' align = 'center' style= width:100% border:1px solid black;>";
     $html.="<td></td>
     <td><label>Номер Студента</label>
         <td><label>Фамилия</label></td>
         <td><label>Имя</label></td>
         <td><label>Средний балл</label></td>
     </td>";
          for($s = 0; $s < $i; $s++){
               $html.="<tr align='center'>";
               $html.="<td><b>$a</b></td>";
               for($j = 0; $j < 4; $j++){
                    $html.="<td>";
                    $html.=$arr[$temp[$s]][$j];
                    $html.="</td>";
                    }
               $html.="</tr>";
               ++$a;
          }
     $html.="</table>";
     $html.="<br><br>";
     echo $html;









     $c=0;
$array; 
for($a=0;$a<$i;$a++)
{
   $array[$c]=$arr[$a][1];
$c++;
}

  asort($array);

$temp;
$c=0;
foreach ($array as $key => $value) {
   $temp[$c]=$key;
   $c++;
}
$a = 1;
$html="<h1 align='center'>По Возрастанию фамилии Студентов</h1>";
$html.="<table border = '2' cellspacing = '0' align = 'center' style= width:100% border:1px solid black;>";
     $html.="<td></td>
     <td><label>Номер Студента</label>
         <td><label>Фамилия</label></td>
         <td><label>Имя</label></td>
         <td><label>Средний балл</label></td>
     </td>";
          for($s = 0; $s < $i; $s++){
               $html.="<tr align='center'>";
               $html.="<td><b>$a</b></td>";
               for($j = 0; $j < 4; $j++){
                    $html.="<td>";
                    $html.=$arr[$temp[$s]][$j];
                    $html.="</td>";
                    }
               $html.="</tr>";
               ++$a;
          }
     $html.="</table>";
     $html.="<br><br>";
     echo $html;












$c=0;
$array; 
for($a=0;$a<$i;$a++)
{
   $array[$c]=$arr[$a][1];
$c++;
}

  arsort($array);

$temp;
$c=0;
foreach ($array as $key => $value) {
   $temp[$c]=$key;
   $c++;
}

$a = 1;
$html="<h1 align='center'>По Убыванию фамилии Студентов</h1>";
$html.="<table border = '2' cellspacing = '0' align = 'center'style= width:100% border:1px solid black;>";
     $html.="<td></td>
     <td><label>Номер Студента</label>
         <td><label>Фамилия</label></td>
         <td><label>Имя</label></td>
         <td><label>Средний балл</label></td>
     </td>";
          for($s = 0; $s < $i; $s++){
               $html.="<tr align='center'>";
               $html.="<td><b>$a</b></td>";
               for($j = 0; $j < 4; $j++){
                    $html.="<td>";
                    $html.=$arr[$temp[$s]][$j];
                    $html.="</td>";
                    }
               $html.="</tr>";
               ++$a;
          }
     $html.="</table>";
     $html.="<br><br>";
     echo $html;


















     $c=0;
$array; 
for($a=0;$a<$i;$a++)
{
   $array[$c]=$arr[$a][2];
$c++;
}

  asort($array);

$temp;
$c=0;
foreach ($array as $key => $value) {
   $temp[$c]=$key;
   $c++;
}
$a = 1;
$html="<h1 align='center'>По Возрастанию имени Студентов</h1>";
$html.="<table border = '2' cellspacing = '0' align = 'center' style= width:100% border:1px solid black;>";
     $html.="<td></td> 
     <td><label>Номер Студента</label>
         <td><label>Фамилия</label></td>
         <td><label>Имя</label></td>
         <td><label>Средний балл</label></td>
     </td>";
          for($s = 0; $s < $i; $s++){
               $html.="<tr align='center'>";
               $html.="<td><b>$a</b></td>";
               for($j = 0; $j < 4; $j++){
                    $html.="<td>";
                    $html.=$arr[$temp[$s]][$j];
                    $html.="</td>";
                    }
               $html.="</tr>";
               ++$a;
          }
     $html.="</table>";
     $html.="<br><br>";
     echo $html;








$c=0;
$array; 
for($a=0;$a<$i;$a++)
{
   $array[$c]=$arr[$a][2];
$c++;
}

  arsort($array);

$temp;
$c=0;
foreach ($array as $key => $value) {
   $temp[$c]=$key;
   $c++;
}

$a = 1;
$html="<h1 align='center'>По Убыванию имени Студентов</h1>";
$html.="<table border = '2' cellspacing = '0' align = 'center' style= width:100% border:1px solid black;>";
     $html.="<td></td>
     <td><label>Номер Студента</label>
         <td><label>Фамилия</label></td>
         <td><label>Имя</label></td>
         <td><label>Средний балл</label></td>
     </td>";
          for($s = 0; $s < $i; $s++){
               $html.="<tr align='center'>";
               $html.="<td><b>$a</b></td>";
               for($j = 0; $j < 4; $j++){
                    $html.="<td>";
                    $html.=$arr[$temp[$s]][$j];
                    $html.="</td>";
                    }
               $html.="</tr>";
               ++$a;
          }
     $html.="</table>";
     $html.="<br><br>";
     echo $html;











     $c=0;
$array; 
for($a=0;$a<$i;$a++)
{
   $array[$c]=$arr[$a][3];
$c++;
}

  asort($array);

$temp;
$c=0;
foreach ($array as $key => $value) {
   $temp[$c]=$key;
   $c++;
}

$a = 1;
$html="<h1 align='center'>По Возрастанию Среднего Балла Студентов</h1>";
$html.="<table border = '2' cellspacing = '0' align = 'center' style= width:100% border:1px solid black;>";
     $html.="<td></td>
     <td><label>Номер Студента</label>
         <td><label>Фамилия</label></td>
         <td><label>Имя</label></td>
         <td><label>Средний балл</label></td>
     </td>";
          for($s = 0; $s < $i; $s++){
               $html.="<tr align='center'>";
               $html.="<td><b>$a</b></td>";
               for($j = 0; $j < 4; $j++){
                    $html.="<td>";
                    $html.=$arr[$temp[$s]][$j];
                    $html.="</td>";
                    }
               $html.="</tr>";
               ++$a;
          }
     $html.="</table>";
     $html.="<br><br>";
     echo $html;








     $c=0;
$array; 
for($a=0;$a<$i;$a++)
{
   $array[$c]=$arr[$a][3];
$c++;
}

  arsort($array);

$temp;
$c=0;
foreach ($array as $key => $value) {
   $temp[$c]=$key;
   $c++;
}
$a = 1;
$html="<h1 align='center'>По Убыванию Среднего Балла Студентов</h1>";
$html.="<table border = '2' cellspacing = '0' align = 'center' style= width:100% border:1px solid black;>";
     $html.="<td></td>
     <td><label>Номер Студента</label>
         <td><label>Фамилия</label></td>
         <td><label>Имя</label></td>
         <td><label>Средний балл</label></td>
     </td>";
          for($s = 0; $s < $i; $s++){
               $html.="<tr align='center'>";
               $html.="<td><b>$a</b></td>";
               for($j = 0; $j < 4; $j++){
                    $html.="<td>";
                    $html.=$arr[$temp[$s]][$j];
                    $html.="</td>";
                    }
               $html.="</tr>";
               ++$a;
          }
     $html.="</table>";
     $html.="<br><br>";
     echo $html;
     
?>

</body>
</html>

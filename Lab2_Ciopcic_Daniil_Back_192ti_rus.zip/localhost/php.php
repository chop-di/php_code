<?php

echo " <h1>оператор if </h1><br>";
$a=1;
$b=5;
echo "a= $a"."<br>";
echo "b= $b"."<br>";
if ($a==$b) {
echo "a равно b"."<br><br>";
};

echo " <h1>оператор if-else </h1><br>";
$a=2;
$b=2;
echo "a= $a"."<br>";
echo "b= $b"."<br>";
if ($a==$b) {
echo "a = b"."<br><br>";
}
else {
echo "a! = b"."<br><br>";
};



echo " <h1>оператор if-elseif-else </h1><br>";
$a=7;
$b=3;
echo "a= $a"."<br>";
echo "b= $b"."<br>";
if ($a>$b) {
echo "a > b"."<br><br>";
}
elseif ($b>$a) {
echo "b > a"."<br><br>";
}
else {
echo "b = a"."<br><br>";
};

?>












<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>ПОбъявление переменных</title>
</head>

<body>

<h1> Объявление переменных</h1>

<?php

echo "Объявление переменных";
echo "<br>";

define("pi", 3.14);
echo pi;

$a;
$b=1;
$c=1.0;

echo $a; echo "<br>";
echo $b; echo "<br>";
echo $c; echo "<br>";

echo "a = $a , b = $b , c = $c"; echo "<br>";
echo 'a = $a , b = $b , c = $c'; echo "<br>";

echo "<br>";

var_dump($a, $b, $c);

echo "<br>";

$b="Это переприсвоенное значение";
echo $b; echo "<br>";
var_dump($b); echo "<br>";

echo "Удаление переменной"; echo "<br>";
unset($b);

echo "b= $b"; echo "<br>";
var_dump($b);

?>
</body>
</html>










<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Функции. Область видимости</title>
</head>
<body>

<?php

echo "Функции. Область видимости";
echo "<br>";

$a = 1.23;
$b = 2;

function f1() {
echo $a; // функциональная область видимости переменной
};

echo "Вызов функции f1()";echo "<br>";
f1();echo "<br>";
echo $c=f2();

function f2() {
global $a, $b; // Глобальная область видимости
echo "a= $a , b= $b"; echo "<br>";
echo $b=$a+$b;
return $b;
};

echo "Вызов функции f2()";echo "<br>";
f2();

echo "a= $a , b= $b"; echo "<br>";

function f3() {
global $a1, $b1; // Глобальная область видимости
echo "a1= $a1 , b1= $b1"; echo "<br>";
$b1=$a1+$b1;
};

echo "Вызов функции f3()";echo "<br>";
f3();

$a1 = 5.23;
$b1 = 7;

?>

</body>
</html>










<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Arrays foreach</title>
</head>
<body>

<?php

echo "Объявление массивов";
echo "<br>";

echo "Объявление массивов - 1способ";
echo "<br>";

$a;
var_dump($a); echo "<br>";
$a[0]='1 element';
$a[1]='2 element';
$a[2]=1.25;
$a[]=5.46;
$a[]=7.986968686e+2;
var_dump($a); echo "<br>";
echo "Вывод элементов массива a[]:"; echo "<br>";
echo "a[0]= $a[0] , a[1]= $a[1] , a[2]= $a[2]";

echo "<br>";echo "<br>";

echo "Объявление массивов - 2способ";
echo "<br>";

$b=array('ghkjhg1','kjdfhdgdhdg2',1.25);
var_dump($b); echo "<br>";

$b1[0][0]=1;
$b2[1][0]=2;


echo "Вывод элементов массива b[]:"; echo "<br>";
echo "b[0]= $b[0] , b[1]= $b[1] , b[2]= $b[2]"; echo "<br>";echo "<br>";

echo "Объявление массивов - 3способ: Ассоциативный массив // пары 'key=>value' ";
echo "<br>";

$c=array('key0'=>'ghkjhg1', 'key1'=>'kjdfhdgdhdg2', 'key2'=>1.25);
var_dump($c); echo "<br>";

echo "Вывод элементов массива c[]:"; echo "<br>";
echo "c[]= $c[key0] , c[]= $c[key1] , c[]= $c[key2]";


?>

</body>
</html>











<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Arrays foreach</title>
</head>
<body>

<?php

echo "Перебор массивов";
echo "<br>";

$a[0]='1 element';
$a[1]='2 element';
$a[2]=1.25;
$a[]=5.46;
$a[]=7.986968686e+2;

echo "1Перебор массивов - глобальные (встроенные) переменные GLOBALS и _SERVER ";
echo "<br>";
foreach ($GLOBALS as $key => $value)
echo "<b>key</b> = $key <b>value = </b> $value <br>";
echo "<br>";

foreach ($_SERVER as $key => $value)
echo "<b>key</b> = $key <b>value = </b> $value <br>";
echo "<br>";

echo "2Перебор массивов - пользовательский массив ";
echo "<br>";

$a[0]='1 element';
$a[1]='2 element';
$a[2]=1.25;
$a[]=5.46;
$a[]=7.986968686e+2;

foreach ($a as $key => $value)
echo "<b>key</b> = $key <b>value = </b> $value <br>";
echo "<br>";

echo "3Перебор массивов - пользовательский массив ";
echo "<br>";

foreach ($a as $key => $value)
echo "a[$key]= $value <br>";

?>

</body>
</html>










<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Document</title>
</head>
<body>
<h1>Сортировка массивов</h1>

<?php
$a=array('a'=>'Moscow','b'=>'Chisinau','c'=>'Kiev','d'=>'Bucharest','e'=>'Iasi');
print_r($a);
echo " <br> Исходный массив <br>";
foreach ($a as $k => $v)
echo "<b>key</b> = $k <b>value = </b> $v <br>";
echo "<br>";

// сортировка sort - сортировка по возр по значения . с отбрасыванием ключей
sort($a);
print_r($a);
echo "Cортировка по значениям по возростанию - sort <br>";
foreach ($a as $value)
echo "<b><b>value = </b> $value <br>";
echo "<br>";

// сортировка rsort
rsort($a);
print_r($a);
echo "Cортировка по значениям по убыванию - rsort <br>";
foreach ($a as $value)
echo "<b>key</b> = $key <b>value = </b> $value <br>";
echo "<br>";

$a=array('a'=>'Moscow','b'=>'Chisinau','c'=>'Kiev','d'=>'Bucharest','e'=>'Iasi');

// сортировка asort
asort($a);
print_r($a);
echo "Cортировка по значениям по возростанию, сохраняя ключи - asort <br>";
foreach ($a as $key => $value)
echo "<b>key</b> = $key <b>value = </b> $value <br>";
echo "<br>";

// сортировка arsort
arsort($a);
print_r($a);
echo "Cортировка по значениям по убыванию, сохраняя ключи - arsort <br>";
foreach ($a as $key => $value)
echo "<b>key</b> = $key <b>value = </b> $value <br>";
echo "<br>";

// сортировка ksort
ksort($a);
print_r($a);
echo "Cортировка по ключам по возростанию - ksort <br>";
foreach ($a as $key => $value)
echo "<b>key</b> = $key <b>value = </b> $value <br>";
echo "<br>";

// сортировка krsort
krsort($a);
print_r($a);
echo "Cортировка по ключам по убыванию - krsort <br>";
foreach ($a as $key => $value)
echo "<b>key</b> = $key <b>value = </b> $value <br>";
echo "<br>";

?>

</body>
</html>





